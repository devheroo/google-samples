# AI Service

A Spring Boot service that provides OpenAI-compatible API endpoints for chat completions. This service can be used as a drop-in replacement for OpenAI's API, allowing other applications to connect to it seamlessly.

## Features

- 🚀 **OpenAI Compatible API** - Fully compatible with OpenAI's chat completion API
- 📚 **Swagger UI Documentation** - Interactive API documentation at `/swagger-ui.html`
- 🔧 **Spring Boot** - Built with Spring Boot 3.2.0 and Java 17
- ✅ **Validation** - Request validation with proper error responses
- 🧪 **Unit Tests** - Comprehensive test coverage
- 🌐 **CORS Support** - Cross-origin resource sharing enabled
- 📊 **Health Checks** - Spring Actuator endpoints for monitoring

## Quick Start

### Prerequisites

- Java 17 or higher
- Maven 3.6 or higher

### Running the Application

1. Clone or download the project
2. Navigate to the project directory
3. Run the application:

```bash
mvn spring-boot:run
```

The service will start on `http://localhost:8080`

### Access Swagger UI

Open your browser and navigate to: `http://localhost:8080/swagger-ui.html`

## API Endpoints

### Chat Completions

**POST** `/v1/chat/completions`

Creates a chat completion response. Compatible with OpenAI's API format.

Example request:
```json
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Hello, how are you?"
    }
  ],
  "temperature": 0.7,
  "max_tokens": 150
}
```

### Models

**GET** `/v1/models` - List available models

**GET** `/v1/models/{model}` - Get specific model information

## Configuration

The application can be configured through `application.properties`:

- `server.port` - Server port (default: 8080)
- `springdoc.swagger-ui.path` - Swagger UI path
- `logging.level.com.example.aiservice` - Logging level

## Usage Examples

### Using with OpenAI Python Client

```python
import openai

# Point to your local AI service
openai.api_base = "http://localhost:8080/v1"
openai.api_key = "your-api-key"  # Optional for this demo

response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "user", "content": "Hello!"}
    ]
)

print(response.choices[0].message.content)
```

### Using with curl

```bash
curl -X POST "http://localhost:8080/v1/chat/completions" \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer your-api-key" \
     -d '{
       "model": "gpt-3.5-turbo",
       "messages": [
         {
           "role": "user",
           "content": "Hello, world!"
         }
       ]
     }'
```

## Supported Parameters

The service supports the following OpenAI API parameters:

- `model` - Model identifier
- `messages` - Array of message objects
- `temperature` - Sampling temperature (0-2)
- `top_p` - Nucleus sampling parameter
- `n` - Number of completions to generate
- `stream` - Whether to stream responses (not implemented in this demo)
- `stop` - Stop sequences
- `max_tokens` - Maximum tokens to generate
- `presence_penalty` - Presence penalty (-2.0 to 2.0)
- `frequency_penalty` - Frequency penalty (-2.0 to 2.0)
- `logit_bias` - Token likelihood modifications
- `user` - End-user identifier

## Available Models

The service provides the following demo models:

- `gpt-3.5-turbo`
- `gpt-3.5-turbo-16k`
- `gpt-4`
- `gpt-4-turbo`

## Response Format

Responses follow the OpenAI API format exactly:

```json
{
  "id": "chatcmpl-123",
  "object": "chat.completion",
  "created": 1677652288,
  "model": "gpt-3.5-turbo",
  "choices": [{
    "index": 0,
    "message": {
      "role": "assistant",
      "content": "Hello! How can I assist you today?"
    },
    "finish_reason": "stop"
  }],
  "usage": {
    "prompt_tokens": 9,
    "completion_tokens": 12,
    "total_tokens": 21
  }
}
```

## Error Handling

The service provides proper error responses matching OpenAI's format:

```json
{
  "error": {
    "message": "Invalid request",
    "type": "invalid_request_error",
    "param": "messages",
    "code": "invalid_request"
  }
}
```

## Testing

Run the unit tests:

```bash
mvn test
```

## Building

Build the application:

```bash
mvn clean package
```

The JAR file will be created in the `target/` directory.

## Deployment

### Running the JAR

```bash
java -jar target/ai-service-1.0.0.jar
```

### Docker (Optional)

You can containerize the application by creating a `Dockerfile`:

```dockerfile
FROM openjdk:17-jre-slim
COPY target/ai-service-1.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "/app.jar"]
```

## Customization

### Implementing Your Own AI Model

To integrate with a real AI model, modify the `AiServiceImpl` class:

1. Replace the `generateResponse` method with calls to your AI model
2. Update token estimation logic
3. Add proper error handling for model failures

### Adding Authentication

To add API key authentication:

1. Create a filter or interceptor to validate API keys
2. Store valid API keys in a database or configuration
3. Return 401 errors for invalid keys

### Adding Rate Limiting

Consider implementing rate limiting using:

- Spring Boot Rate Limiter
- Redis-based rate limiting
- API Gateway solutions

## Monitoring

The service includes Spring Actuator endpoints:

- `/actuator/health` - Health check
- `/actuator/info` - Application information
- `/actuator/metrics` - Application metrics

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For questions or issues, please contact the development team or create an issue in the project repository.