package com.example.aiservice.controller;

import com.example.aiservice.dto.ErrorResponse;
import com.example.aiservice.dto.ModelsResponse;
import com.example.aiservice.service.AiService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/v1")
@RequiredArgsConstructor
@Tag(name = "Models", description = "Model management endpoints")
public class ModelsController {

    private final AiService aiService;

    @Operation(
        summary = "List models",
        description = "Lists the currently available models, and provides basic information about each one",
        security = @SecurityRequirement(name = "bearerAuth")
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully retrieved models list",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ModelsResponse.class)
            )
        ),
        @ApiResponse(
            responseCode = "401",
            description = "Authentication required",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class)
            )
        )
    })
    @GetMapping("/models")
    public ResponseEntity<ModelsResponse> getModels(
        @Parameter(description = "Authorization header", example = "Bearer sk-...")
        @RequestHeader(value = "Authorization", required = false) String authorization
    ) {
        log.info("Received request to list models");
        ModelsResponse response = aiService.getModels();
        return ResponseEntity.ok(response);
    }

    @Operation(
        summary = "Retrieve model",
        description = "Retrieves a model instance, providing basic information about the model",
        security = @SecurityRequirement(name = "bearerAuth")
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Successfully retrieved model information",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ModelsResponse.Model.class)
            )
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Model not found",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class)
            )
        ),
        @ApiResponse(
            responseCode = "401",
            description = "Authentication required",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = ErrorResponse.class)
            )
        )
    })
    @GetMapping("/models/{model}")
    public ResponseEntity<ModelsResponse.Model> getModel(
        @Parameter(description = "Authorization header", example = "Bearer sk-...")
        @RequestHeader(value = "Authorization", required = false) String authorization,
        @Parameter(description = "The ID of the model to use for this request", example = "gpt-3.5-turbo")
        @PathVariable String model
    ) {
        log.info("Received request to get model: {}", model);
        ModelsResponse.Model modelInfo = aiService.getModel(model);
        
        if (modelInfo == null) {
            return ResponseEntity.notFound().build();
        }
        
        return ResponseEntity.ok(modelInfo);
    }
}