package com.example.aiservice.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Error response matching OpenAI format")
public class ErrorResponse {
    
    @Schema(description = "Error details")
    private Error error;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Schema(description = "Error details")
    public static class Error {
        
        @Schema(description = "Error message", example = "Invalid request")
        private String message;
        
        @Schema(description = "Error type", example = "invalid_request_error")
        private String type;
        
        @Schema(description = "Error parameter", example = "messages")
        private String param;
        
        @Schema(description = "Error code", example = "invalid_request")
        private String code;
    }
}