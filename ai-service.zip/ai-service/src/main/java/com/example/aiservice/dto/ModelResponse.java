package com.example.aiservice.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "List of available models")
public class ModelsResponse {
    
    @Schema(description = "The object type", example = "list")
    private String object;
    
    @Schema(description = "List of available models")
    private List<Model> data;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Schema(description = "Model information")
    public static class Model {
        
        @Schema(description = "Model identifier", example = "gpt-3.5-turbo")
        private String id;
        
        @Schema(description = "The object type", example = "model")
        private String object;
        
        @Schema(description = "Unix timestamp of when the model was created", example = "1677610602")
        private Long created;
        
        @JsonProperty("owned_by")
        @Schema(description = "Organization that owns the model", example = "openai")
        private String ownedBy;
        
        @Schema(description = "List of permissions for the model")
        private List<Permission> permission;
        
        @Schema(description = "Root model identifier", example = "gpt-3.5-turbo")
        private String root;
        
        @Schema(description = "Parent model identifier")
        private String parent;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Schema(description = "Model permission")
    public static class Permission {
        
        @Schema(description = "Permission identifier")
        private String id;
        
        @Schema(description = "The object type", example = "model_permission")
        private String object;
        
        @Schema(description = "Unix timestamp when permission was created")
        private Long created;
        
        @JsonProperty("allow_create_engine")
        private Boolean allowCreateEngine;
        
        @JsonProperty("allow_sampling")
        private Boolean allowSampling;
        
        @JsonProperty("allow_logprobs")
        private Boolean allowLogprobs;
        
        @JsonProperty("allow_search_indices")
        private Boolean allowSearchIndices;
        
        @JsonProperty("allow_view")
        private Boolean allowView;
        
        @JsonProperty("allow_fine_tuning")
        private Boolean allowFineTuning;
        
        @Schema(description = "Organization identifier")
        private String organization;
        
        @Schema(description = "Group identifier")
        private String group;
        
        @JsonProperty("is_blocking")
        private Boolean isBlocking;
    }
}