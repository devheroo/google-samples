package com.example.aiservice.service.impl;

import com.example.aiservice.dto.ChatCompletionRequest;
import com.example.aiservice.dto.ChatCompletionResponse;
import com.example.aiservice.dto.ChatMessage;
import com.example.aiservice.dto.ModelsResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class AiServiceImplTest {

    @InjectMocks
    private AiServiceImpl aiService;

    @Test
    void createChatCompletion_HelloMessage_ReturnsGreeting() {
        // Arrange
        ChatMessage userMessage = new ChatMessage("user", "Hello there!", null);
        ChatCompletionRequest request = new ChatCompletionRequest();
        request.setModel("gpt-3.5-turbo");
        request.setMessages(List.of(userMessage));

        // Act
        ChatCompletionResponse response = aiService.createChatCompletion(request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getObject()).isEqualTo("chat.completion");
        assertThat(response.getModel()).isEqualTo("gpt-3.5-turbo");
        assertThat(response.getChoices()).hasSize(1);
        assertThat(response.getChoices().get(0).getMessage().getRole()).isEqualTo("assistant");
        assertThat(response.getChoices().get(0).getMessage().getContent()).contains("Hello");
        assertThat(response.getUsage().getTotalTokens()).isPositive();
    }

    @Test
    void createChatCompletion_WeatherQuestion_ReturnsWeatherResponse() {
        // Arrange
        ChatMessage userMessage = new ChatMessage("user", "What's the weather like?", null);
        ChatCompletionRequest request = new ChatCompletionRequest();
        request.setModel("gpt-4");
        request.setMessages(List.of(userMessage));

        // Act
        ChatCompletionResponse response = aiService.createChatCompletion(request);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getChoices().get(0).getMessage().getContent()).contains("weather");
    }

    @Test
    void getModels_ReturnsAvailableModels() {
        // Act
        ModelsResponse response = aiService.getModels();

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getObject()).isEqualTo("list");
        assertThat(response.getData()).isNotEmpty();
        assertThat(response.getData()).anyMatch(model -> model.getId().equals("gpt-3.5-turbo"));
        assertThat(response.getData()).anyMatch(model -> model.getId().equals("gpt-4"));
    }

    @Test
    void getModel_ExistingModel_ReturnsModelInfo() {
        // Act
        ModelsResponse.Model model = aiService.getModel("gpt-3.5-turbo");

        // Assert
        assertThat(model).isNotNull();
        assertThat(model.getId()).isEqualTo("gpt-3.5-turbo");
        assertThat(model.getObject()).isEqualTo("model");
        assertThat(model.getOwnedBy()).isEqualTo("ai-service");
    }

    @Test
    void getModel_NonExistingModel_ReturnsNull() {
        // Act
        ModelsResponse.Model model = aiService.getModel("non-existing-model");

        // Assert
        assertThat(model).isNull();
    }
}