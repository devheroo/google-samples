package com.example.aiservice.controller;

import com.example.aiservice.dto.ChatCompletionRequest;
import com.example.aiservice.dto.ChatCompletionResponse;
import com.example.aiservice.dto.ChatMessage;
import com.example.aiservice.service.AiService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ChatController.class)
class ChatControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AiService aiService;

    @Test
    void createChatCompletion_Success() throws Exception {
        // Arrange
        ChatMessage userMessage = new ChatMessage("user", "Hello", null);
        ChatCompletionRequest request = new ChatCompletionRequest();
        request.setModel("gpt-3.5-turbo");
        request.setMessages(List.of(userMessage));

        ChatMessage responseMessage = new ChatMessage("assistant", "Hello! How can I help you?", null);
        ChatCompletionResponse.Choice choice = new ChatCompletionResponse.Choice(0, responseMessage, null, "stop");
        ChatCompletionResponse.Usage usage = new ChatCompletionResponse.Usage(5, 10, 15);
        
        ChatCompletionResponse response = new ChatCompletionResponse(
            "chatcmpl-123", "chat.completion", 1677652288L, "gpt-3.5-turbo", 
            List.of(choice), usage, null
        );

        when(aiService.createChatCompletion(any(ChatCompletionRequest.class))).thenReturn(response);

        // Act & Assert
        mockMvc.perform(post("/v1/chat/completions")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("chatcmpl-123"))
                .andExpect(jsonPath("$.object").value("chat.completion"))
                .andExpect(jsonPath("$.model").value("gpt-3.5-turbo"))
                .andExpect(jsonPath("$.choices[0].message.role").value("assistant"))
                .andExpect(jsonPath("$.choices[0].message.content").value("Hello! How can I help you?"))
                .andExpect(jsonPath("$.usage.total_tokens").value(15));
    }

    @Test
    void createChatCompletion_InvalidRequest() throws Exception {
        // Arrange - Empty request
        ChatCompletionRequest request = new ChatCompletionRequest();

        // Act & Assert
        mockMvc.perform(post("/v1/chat/completions")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }
}