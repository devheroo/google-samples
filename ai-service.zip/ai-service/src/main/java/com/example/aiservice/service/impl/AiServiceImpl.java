package com.example.aiservice.service.impl;

import com.example.aiservice.dto.ChatCompletionRequest;
import com.example.aiservice.dto.ChatCompletionResponse;
import com.example.aiservice.dto.ChatMessage;
import com.example.aiservice.dto.ModelsResponse;
import com.example.aiservice.service.AiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
public class AiServiceImpl implements AiService {

    private static final List<ModelsResponse.Model> AVAILABLE_MODELS = createAvailableModels();

    @Override
    public ChatCompletionResponse createChatCompletion(ChatCompletionRequest request) {
        log.info("Creating chat completion for model: {}", request.getModel());
        
        // Generate response based on the last user message
        String responseContent = generateResponse(request);
        
        ChatMessage responseMessage = new ChatMessage("assistant", responseContent, null);
        
        ChatCompletionResponse.Choice choice = new ChatCompletionResponse.Choice(
            0, responseMessage, null, "stop"
        );
        
        // Calculate token usage (simplified estimation)
        int promptTokens = estimateTokens(request.getMessages());
        int completionTokens = estimateTokens(responseContent);
        
        ChatCompletionResponse.Usage usage = new ChatCompletionResponse.Usage(
            promptTokens, completionTokens, promptTokens + completionTokens
        );
        
        return new ChatCompletionResponse(
            "chatcmpl-" + UUID.randomUUID().toString().substring(0, 8),
            "chat.completion",
            Instant.now().getEpochSecond(),
            request.getModel(),
            List.of(choice),
            usage,
            null
        );
    }

    @Override
    public ModelsResponse getModels() {
        return new ModelsResponse("list", new ArrayList<>(AVAILABLE_MODELS));
    }

    @Override
    public ModelsResponse.Model getModel(String modelId) {
        return AVAILABLE_MODELS.stream()
            .filter(model -> model.getId().equals(modelId))
            .findFirst()
            .orElse(null);
    }

    private String generateResponse(ChatCompletionRequest request) {
        // Simple response generation logic
        // In a real implementation, this would call your AI model
        
        ChatMessage lastMessage = request.getMessages().get(request.getMessages().size() - 1);
        String userInput = lastMessage.getContent().toLowerCase();
        
        if (userInput.contains("hello") || userInput.contains("hi")) {
            return "Hello! How can I assist you today?";
        } else if (userInput.contains("how are you")) {
            return "I'm doing well, thank you for asking! I'm here to help you with any questions you might have.";
        } else if (userInput.contains("weather")) {
            return "I don't have access to current weather data, but you can check your local weather service for accurate forecasts.";
        } else if (userInput.contains("time")) {
            return "I don't have access to real-time information, but you can check your device's clock for the current time.";
        } else {
            return "Thank you for your message. I understand you're asking about: \"" + lastMessage.getContent() + 
                   "\". This is a demo AI service with basic responses. In a production environment, " +
                   "this would be connected to a real AI model.";
        }
    }

    private int estimateTokens(List<ChatMessage> messages) {
        return messages.stream()
            .mapToInt(msg -> estimateTokens(msg.getContent()))
            .sum();
    }

    private int estimateTokens(String text) {
        // Simple token estimation: roughly 1 token per 4 characters
        return Math.max(1, text.length() / 4);
    }

    private static List<ModelsResponse.Model> createAvailableModels() {
        List<ModelsResponse.Model> models = new ArrayList<>();
        
        // Create permission object
        ModelsResponse.Permission permission = new ModelsResponse.Permission();
        permission.setId("modelperm-" + UUID.randomUUID().toString());
        permission.setObject("model_permission");
        permission.setCreated(Instant.now().getEpochSecond());
        permission.setAllowCreateEngine(false);
        permission.setAllowSampling(true);
        permission.setAllowLogprobs(true);
        permission.setAllowSearchIndices(false);
        permission.setAllowView(true);
        permission.setAllowFineTuning(false);
        permission.setOrganization("*");
        permission.setGroup(null);
        permission.setIsBlocking(false);

        // Add demo models
        models.add(createModel("gpt-3.5-turbo", "ai-service", permission));
        models.add(createModel("gpt-3.5-turbo-16k", "ai-service", permission));
        models.add(createModel("gpt-4", "ai-service", permission));
        models.add(createModel("gpt-4-turbo", "ai-service", permission));
        
        return models;
    }

    private static ModelsResponse.Model createModel(String id, String ownedBy, ModelsResponse.Permission permission) {
        ModelsResponse.Model model = new ModelsResponse.Model();
        model.setId(id);
        model.setObject("model");
        model.setCreated(Instant.now().getEpochSecond());
        model.setOwnedBy(ownedBy);
        model.setPermission(List.of(permission));
        model.setRoot(id);
        model.setParent(null);
        return model;
    }
}