package com.example.aiservice.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "A chat message in the conversation")
public class ChatMessage {
    
    @NotNull
    @Schema(description = "The role of the message author", 
            example = "user", 
            allowableValues = {"system", "user", "assistant"})
    private String role;
    
    @NotBlank
    @Schema(description = "The content of the message", example = "Hello, how are you?")
    private String content;
    
    @Schema(description = "An optional name for the participant", example = "John")
    private String name;
}