package com.example.aiservice.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Chat completion request matching OpenAI format")
public class ChatCompletionRequest {
    
    @NotNull
    @Schema(description = "ID of the model to use", example = "gpt-3.5-turbo")
    private String model;
    
    @NotEmpty
    @Valid
    @Schema(description = "The messages to generate chat completions for")
    private List<ChatMessage> messages;
    
    @Schema(description = "What sampling temperature to use, between 0 and 2", 
            example = "1", minimum = "0", maximum = "2")
    private Double temperature;
    
    @JsonProperty("top_p")
    @Schema(description = "Nucleus sampling parameter", 
            example = "1", minimum = "0", maximum = "1")
    private Double topP;
    
    @Schema(description = "How many chat completion choices to generate", 
            example = "1", minimum = "1")
    private Integer n;
    
    @Schema(description = "Whether to stream back partial message deltas")
    private Boolean stream;
    
    @Schema(description = "Up to 4 sequences where the API will stop generating further tokens")
    private List<String> stop;
    
    @JsonProperty("max_tokens")
    @Schema(description = "Maximum number of tokens to generate", 
            example = "100", minimum = "1")
    private Integer maxTokens;
    
    @JsonProperty("presence_penalty")
    @Schema(description = "Penalize new tokens based on presence in text so far", 
            minimum = "-2.0", maximum = "2.0")
    private Double presencePenalty;
    
    @JsonProperty("frequency_penalty")
    @Schema(description = "Penalize new tokens based on frequency in text so far", 
            minimum = "-2.0", maximum = "2.0")
    private Double frequencyPenalty;
    
    @JsonProperty("logit_bias")
    @Schema(description = "Modify likelihood of specified tokens appearing")
    private Map<String, Double> logitBias;
    
    @Schema(description = "A unique identifier representing your end-user")
    private String user;
}