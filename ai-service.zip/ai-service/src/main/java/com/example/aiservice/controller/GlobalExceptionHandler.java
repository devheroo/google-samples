package com.example.aiservice.exception;

import com.example.aiservice.dto.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.stream.Collectors;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationExceptions(MethodArgumentNotValidException ex) {
        String message = ex.getBindingResult().getFieldErrors().stream()
            .map(FieldError::getDefaultMessage)
            .collect(Collectors.joining(", "));
        
        ErrorResponse.Error error = new ErrorResponse.Error(
            "Validation failed: " + message,
            "invalid_request_error",
            null,
            "invalid_request"
        );
        
        log.error("Validation error: {}", message);
        return ResponseEntity.badRequest().body(new ErrorResponse(error));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> handleHttpMessageNotReadableException(HttpMessageNotReadableException ex) {
        ErrorResponse.Error error = new ErrorResponse.Error(
            "Invalid JSON format in request body",
            "invalid_request_error",
            null,
            "invalid_request"
        );
        
        log.error("Invalid JSON format: {}", ex.getMessage());
        return ResponseEntity.badRequest().body(new ErrorResponse(error));
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorResponse> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex) {
        ErrorResponse.Error error = new ErrorResponse.Error(
            "Invalid parameter type: " + ex.getName(),
            "invalid_request_error",
            ex.getName(),
            "invalid_request"
        );
        
        log.error("Type mismatch error: {}", ex.getMessage());
        return ResponseEntity.badRequest().body(new ErrorResponse(error));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> handleIllegalArgumentException(IllegalArgumentException ex) {
        ErrorResponse.Error error = new ErrorResponse.Error(
            ex.getMessage(),
            "invalid_request_error",
            null,
            "invalid_request"
        );
        
        log.error("Illegal argument: {}", ex.getMessage());
        return ResponseEntity.badRequest().body(new ErrorResponse(error));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(Exception ex) {
        ErrorResponse.Error error = new ErrorResponse.Error(
            "An internal error occurred",
            "internal_error",
            null,
            "internal_error"
        );
        
        log.error("Internal error", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(new ErrorResponse(error));
    }
}