package com.example.aiservice.service;

import com.example.aiservice.dto.ChatCompletionRequest;
import com.example.aiservice.dto.ChatCompletionResponse;
import com.example.aiservice.dto.ModelsResponse;

public interface AiService {
    
    /**
     * Create a chat completion
     * @param request The chat completion request
     * @return The chat completion response
     */
    ChatCompletionResponse createChatCompletion(ChatCompletionRequest request);
    
    /**
     * Get list of available models
     * @return The models response
     */
    ModelsResponse getModels();
    
    /**
     * Get information about a specific model
     * @param modelId The model identifier
     * @return The model information
     */
    ModelsResponse.Model getModel(String modelId);
}